
This Automation Corresponds to multiple client testing  in periscopix.
 The main aim is to automate the functional test cases so that this could be further improved to Google Analytics testing scope.

# Peris_GA_Java_Cucumber_Auto
This tests corresponds to Periscopix organisation using open source tools of java, maven, cucumber


~~~ Integrated with jenkins. For each code push there will be a build run from now. checking still....