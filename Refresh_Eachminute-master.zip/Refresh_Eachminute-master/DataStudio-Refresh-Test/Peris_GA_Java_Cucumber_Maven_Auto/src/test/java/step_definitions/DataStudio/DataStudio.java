package step_definitions.DataStudio;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import step_definitions.support.Report;
import step_definitions.support.SeleniumBase;

import java.util.Date;

public class DataStudio {

    SeleniumBase sb = new SeleniumBase();

    @Given("^I navigate to Datastudio url$")
    public void i_navigate_to_Datastudio_url() throws Throwable {

        sb.navigate("DataStudioUrl");
        Thread.sleep(1000);
        sb.assertUrl("AssertDataStudio");
        Thread.sleep(1000);

    }

    @Then("^I input user id in the text box$")
    public void i_input_user_id_in_the_text_box() throws Throwable {

        sb.textBoxInput("username", "uservalue");
        Thread.sleep(1000);
        sb.click("NextButton");
        Thread.sleep(1000);

    }

    @Then("^I navigate to the provide password page$")
    public void i_navigate_to_the_provide_password_page() throws Throwable {
        sb.assertUrl("AssertPassurl");
        Thread.sleep(1000);

    }

    @Then("^I provide the password$")
    public void i_provide_the_password() throws Throwable {
        sb.textBoxInput("PassBox", "passvalue");
        Thread.sleep(3000);
        sb.click("Signinbutton");
        Thread.sleep(10000);
        sb.assertTitle("AssertDSTitle");
        Thread.sleep(3000);

    }

    @Then("^I click on Testing report for selenium hyperlink$")
    public void i_click_on_Testing_report_for_selenium_hyperlink() throws Throwable {

        sb.clickByPartLinkText("LinkTextReport");
        Thread.sleep(10000);
    }

    @Then("^I navigate to report page$")
    public void i_navigate_to_report_page() throws Throwable {
        sb.assertUrl("ReportLink");

    }

    @Then("^I click on refresh button$")
    public void i_click_on_refresh_button() throws Throwable {
                Date dt = new Date();
                sb.clickbyCss("clickRefreshclass");
                Report.info( " Latest refresh on : " + dt);
                Thread.sleep(2000);
            }


    }

